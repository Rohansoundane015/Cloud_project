print('hello')
print('te')
